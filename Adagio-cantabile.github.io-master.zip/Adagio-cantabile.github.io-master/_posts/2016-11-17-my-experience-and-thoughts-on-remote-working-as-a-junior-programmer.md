---
layout: post
title:  "My Experience And Thoughts on Remote Working as A Junior Programmer"
date:   2016-11-15 17:31:00 +0800
comments: true
tags:
- programming
- life
---

### About Me And My Job

I started my current job a year ago when I was an exchange student in Japan, I was second year in university then. I worked in the office for 9 months, after that my exchange year ended, I went back to my home university and started remote working since then. Until now, it has been half year.

I rent an apartment and lived alone near my university. I'm not full-time employed, I worked for about 5 hours a day, every day in the week because I found this schedule suits me better. When I'm not working, I go to classes, playing the piano or reading books.

### My Half Year on Remote Working

#### good parts

The best part of remote working is much more free time. I don't have to wake up early and spend hours on a crowded subway to the office, I could spend more time on doing whatever I want to do.

Also for me, working from home is easier to concentrate because there are fewer distractions.

<img src="/img/remote_working.jpg" style="height:50%;width:50%;">
<p style="font-size:14px">My desktop and my friends  o(●´ω｀●)oわくわく♪</p>


#### challenges for a junior programmer

For me, the biggest challenge is finding out the solution to the problem independently. As a junior developer, I don't have much experience, when I encounter a problem that appears for the first time, it's hard to get response from my colleges immediately, more often, I have to find out how to handle it by myself, sometimes it's quite hard because I really don't know what to do with it, and have to dig really deep on the problem.

The second is about confirming specification. When I just started remote working, it's quite often to get confused with specification in junior year, and confirming specification online usually takes more time than face to face, and I have to make sure my colleges are available at that time.

Another challenge is about building up habits. For me, I don't have a fixed working schedule, sometimes I find it hard to get myself backing to working from the lure of reading Reddit or watching Youtube videos. It needs self-discipline to keep myself from slacking off.

#### mental challenges

It's easy to feel emotionally detached with other people. Since I live alone, and my colleges are all in another country, I feel lonely from time to time. I can't keep being productive if I feel lonely. It's not healthy to keep sitting in front of a desktop for all day, going out and networking is also important.

### My Thinkings

I loved my current living style. I can get my work done and do whatever I want to do. For me, it's not easy at first, half year later, I enjoy more and more.
